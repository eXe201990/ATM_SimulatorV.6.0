package ro.oldtech.curs.java.enums;

public enum EnumBanca {

	BANCA_1, BANCA_2, BANCA_3, BANCA_4, BANCA_5, BANCA_6, BANCA_7, BANCA_8, BANCA_9;

}
