package ro.oldtech.curs.java.enums;

public enum EnumStariiTranzactii {

	NONE, EXTRAGERE, DEPUNERE, EROARE, LIMITA_ATINSA;

}
