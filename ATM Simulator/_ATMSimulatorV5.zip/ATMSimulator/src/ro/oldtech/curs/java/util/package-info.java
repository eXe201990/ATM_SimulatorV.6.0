/**
 * 
 */
/**
 * @author george.sand
 *
 */
package ro.oldtech.curs.java.util;